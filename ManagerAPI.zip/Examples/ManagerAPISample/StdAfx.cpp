//+------------------------------------------------------------------+
//|                                                       MetaTrader |
//|                             Copyright 2000-2021, MetaQuotes Ltd. |
//|                                               www.metaquotes.net |
//+------------------------------------------------------------------+
// stdafx.cpp : source file that includes just the standard includes
//   ManagerAPISample.pch will be the pre-compiled header
//   stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"
//+------------------------------------------------------------------+
